# TWRP device tree (DRAFT, untested): Realme C51 RMX3830 (Unisoc UMS9230, Android 15)

Generated from your stock vendor_boot.img (v4) and boot.img (v4, GKI 5.15.149).

* Recovery goes into vendor_boot. boot.img (kernel) stays stock.
* prebuilt/dtb.img = DTB extracted from stock vendor_boot.
* recovery/root/lib/modules = the 171 stock modules (display, USB, UFS, touch).
* recovery/root/system/etc/recovery.fstab.stock = the stock fstab for reference.

## Unverified items (check on the phone)
1. ro.product.device may not be "RMX3830": run `adb shell getprop ro.product.device`.
2. BOARD_SUPER_PARTITION_SIZE: `blockdev --getsize64 /dev/block/by-name/super`.
3. Backlight path/brightness and the touch/display modules.
4. Use a TWRP minimal manifest that supports vendor_boot recovery (Android 12.1+ branch, e.g. a 14 fork). Plain android-11 will not work.

## Flash
fastboot flash vendor_boot_a out/target/product/RMX3830/vendor_boot.img
fastboot flash vendor_boot_b ...
fastboot --disable-verity --disable-verification flash vbmeta vbmeta.img   (stock vbmeta)
Keep your stock vendor_boot.img to restore. /data decryption may not work at first.
