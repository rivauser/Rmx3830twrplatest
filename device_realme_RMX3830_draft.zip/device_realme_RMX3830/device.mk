LOCAL_PATH := device/realme/RMX3830

# A/B + dynamic partitions
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += boot vendor_boot dtbo vbmeta vbmeta_system vbmeta_vendor
PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_PACKAGES += update_engine update_engine_sideload update_verifier
PRODUCT_PACKAGES += otapreopt_script

# Stock kernel modules (display, USB, UFS, touch...) are loaded from the ramdisk
PRODUCT_COPY_FILES += $(call find-copy-subdir-files,*,$(LOCAL_PATH)/recovery/root/lib/modules,$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules)
