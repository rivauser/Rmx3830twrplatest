LOCAL_PATH := device/realme/RMX3830

# A/B + dynamic partitions
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += boot vendor_boot dtbo vbmeta vbmeta_system vbmeta_vendor
PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_PACKAGES += update_engine update_engine_sideload update_verifier
PRODUCT_PACKAGES += otapreopt_script

# Stock kernel modules live in recovery/root/lib/modules; TWRP copies that folder
# into the ramdisk automatically (PRODUCT_COPY_FILES rejects .ko files).
