LOCAL_PATH := device/realme/RMX3830

# A/B + dynamic partitions
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += boot vendor_boot dtbo vbmeta vbmeta_system vbmeta_vendor
PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_PACKAGES += update_engine update_engine_sideload update_verifier
PRODUCT_PACKAGES += otapreopt_script

# Stock kernel modules live in recovery/root/lib/modules; TWRP copies that folder
# into the ramdisk automatically (PRODUCT_COPY_FILES rejects .ko files).

# Non-ELF module metadata files; also makes sure the vendor_ramdisk dir exists.
# (The .ko files themselves are included via recovery/root/lib/modules.)
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/recovery/root/lib/modules/modules.load:$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules/modules.load \
    $(LOCAL_PATH)/recovery/root/lib/modules/modules.load.recovery:$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules/modules.load.recovery \
    $(LOCAL_PATH)/recovery/root/lib/modules/modules.dep:$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules/modules.dep \
    $(LOCAL_PATH)/recovery/root/lib/modules/modules.alias:$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules/modules.alias \
    $(LOCAL_PATH)/recovery/root/lib/modules/modules.softdep:$(TARGET_COPY_OUT_VENDOR_RAMDISK)/lib/modules/modules.softdep
