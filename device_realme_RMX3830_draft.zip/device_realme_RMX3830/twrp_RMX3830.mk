# Draft TWRP product for Realme C51 (RMX3830), Unisoc UMS9230
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit_only.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/base.mk)
$(call inherit-product, vendor/twrp/config/common.mk)
$(call inherit-product, $(LOCAL_PATH)/device.mk)

PRODUCT_DEVICE := RMX3830
PRODUCT_NAME := twrp_RMX3830
PRODUCT_BRAND := realme
PRODUCT_MODEL := RMX3830
PRODUCT_MANUFACTURER := realme
